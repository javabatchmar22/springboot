package com.vinsguru.orderservice.dto;

public enum OrderStatus {

    COMPLETED,
    FAILED;

}
