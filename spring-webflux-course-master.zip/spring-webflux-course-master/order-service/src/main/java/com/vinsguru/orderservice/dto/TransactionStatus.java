package com.vinsguru.orderservice.dto;

public enum TransactionStatus {
    APPROVED,
    DECLINED;
}
