package com.vinsguru.userservice.dto;

public enum TransactionStatus {
    APPROVED,
    DECLINED;
}
