package com.example.springjwt.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.example.springjwt.model.User;

@Service
public class UserService {

	private List<User> store = new ArrayList<User>();
	
	public UserService() {
		store.add(new User(UUID.randomUUID().toString(), "Suyog Kulkarni", "suyog.kulkarni@gmail.com"));
		store.add(new User(UUID.randomUUID().toString(), "Sharman Doshi", "sharman.doshi@gmail.com"));
		store.add(new User(UUID.randomUUID().toString(), "Harsh Sharma", "harsh.sharma@gmail.com"));
		store.add(new User(UUID.randomUUID().toString(), "Ayush Pande", "ayush.pande@gmail.com"));
	}

	public List<User> getUsers() {
		return store;
	}

	public void setUsers(List<User> store) {
		this.store = store;
	}
	
	
}
