package com.github.akhuntsaria.authservice.model;

public enum UserRole {
    USER
}
