package com.github.akhuntsaria.apigateway.model;

public enum UserRole {
    USER
}
